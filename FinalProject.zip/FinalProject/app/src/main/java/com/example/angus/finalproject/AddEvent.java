package com.example.angus.finalproject;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class AddEvent extends AppCompatActivity {


    private Button mScheduleEventButton;
    private EditText mNameEditText;
    private EditText mLocationEditText;
    private EditText mDate;
    private RadioButton mHighRadioButton;
    private RadioButton mMedRadioButton;
    private RadioButton mLowRadioButton;
    private TextView mTestTextView;
    private RadioGroup mRadioGroup;

    MyDBHandler dbHandler;

    private String buttonResponse(){
        if(mHighRadioButton.isChecked()){
            return "High";
        }else if(mMedRadioButton.isChecked()){
            return "Medium";
        }else{
            return "Low";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        mScheduleEventButton = (Button)findViewById(R.id.schedule_button);
        mNameEditText = (EditText)findViewById(R.id.name_edit_text);
        mLocationEditText = (EditText)findViewById(R.id.location_edit_text);
        mDate = (EditText)findViewById(R.id.date_edit_text);
        mTestTextView = (TextView)findViewById(R.id.testTextView);
        mHighRadioButton = (RadioButton)findViewById(R.id.high_importance_rbutton);
        mMedRadioButton = (RadioButton)findViewById(R.id.med_importance_rbutton);
        mLowRadioButton = (RadioButton)findViewById(R.id.low_importance_rbutton);
        mRadioGroup = (RadioGroup)findViewById(R.id.rgroup);
        mRadioGroup.check(R.id.med_importance_rbutton);

        dbHandler = new MyDBHandler(this, null, null, 1);

        mScheduleEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(checkErrors() == false){
                        dbHandler.addEvent(mNameEditText.getText().toString(), mLocationEditText.getText().toString(),
                                mDate.getText().toString(), buttonResponse());
                        mTestTextView.setText("New record inserted!");
                    }
            }
        });

    }//end oncreate


        public void clearFields(){
        mNameEditText.setText("");
        mLocationEditText.setText("");
        mDate.setText("");
        mRadioGroup.check(R.id.med_importance_rbutton);
    }

    public boolean checkErrors(){
        if(mNameEditText.getText().toString().trim().length() == 0){
            mNameEditText.requestFocus();
            mNameEditText.setError("Activity Name can't be empty");
            return true;
        }else if(mLocationEditText.getText().toString().trim().length() == 0){
            mLocationEditText.requestFocus();
            mLocationEditText.setError("Location can't be empty");
            return true;
        }else if(mDate.getText().toString().trim().length() == 0) {
            mDate.requestFocus();
            mDate.setError("Date can't be empty");
            return true;
        }else if(mDate.getText().toString().trim().length() < 10){
            mDate.requestFocus();
            mDate.setError("Date must follow the format MM/DD/YYYY with slashes");
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add_event, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
