package com.example.angus.finalproject;

/**
 * Created by Angus on 2015-12-03.
 */

import com.example.angus.finalproject.DataProvider;

import android.content.ContentResolver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;

import java.util.ArrayList;
import java.util.List;


public class MyDBHandler extends SQLiteOpenHelper {

    private ContentResolver myCR;

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "events.db";
    public static final String TABLE_EVENTS = "events";

    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DATE = "edate";
    public static final String COLUMN_PRIORITY = "priority";


    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
        myCR = context.getContentResolver();
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_EVENTS + "( " +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME  + " TEXT, " +
                COLUMN_LOCATION  + " TEXT, " +
                COLUMN_DATE  + " TEXT, " +
                COLUMN_PRIORITY  +  " TEXT " +
                ")";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    public void dropTable(SQLiteDatabase db){
        db.execSQL("DROP TABLE " + TABLE_EVENTS);
    }

    //add new row to the database
    public void addEvent(String event, String location, String date, String priority){
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, event);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_PRIORITY, priority);

        myCR.insert(DataProvider.CONTENT_URI, values);
    }

    //delete a scheduled event

    public boolean deleteEvent(String event){

        boolean result = false;

        String selection = "name = \"" + event + "\"";

        int rowsDeleted = myCR.delete(DataProvider.CONTENT_URI,
                selection, null);

        if (rowsDeleted > 0)
            result = true;

        return result;
    }

    //in case I use a dropdown. Keep this.
    public List<String> databaseToArray(){
        List<String> events = new ArrayList<String>();

        SQLiteDatabase db = getWritableDatabase();
        String query = "Select * FROM " + TABLE_EVENTS + " WHERE 1";

        Cursor c = db.rawQuery(query, null);
        int i = 0;
        c.moveToFirst();
        while(!c.isAfterLast()){
            if(c.getString(c.getColumnIndex("name")) != null){
                events.add(i,c.getString(c.getColumnIndex("name")));
                i++;
                c.moveToNext();
            }
        }

        return events;
    }

    public String databaseToString(){
        String dbString = "";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_EVENTS + " WHERE 1";

        //Cursor point to a location in your results
        Cursor c = db.rawQuery(query, null);

        c.moveToFirst();

        while(!c.isAfterLast()){
            if(c.getString(c.getColumnIndex("name")) != null){
                dbString += "Event Name: ";
                dbString += c.getString(c.getColumnIndex("name"));
                dbString += " Event Location: ";
                dbString += c.getString(c.getColumnIndex("location"));
                dbString += " Date: ";
                dbString += c.getString(c.getColumnIndex("edate"));
                dbString += " Priority: ";
                dbString += c.getString(c.getColumnIndex("priority"));
                dbString += "\n\n";
                c.moveToNext();
            }
        }
        db.close();
        return dbString;

    }
}